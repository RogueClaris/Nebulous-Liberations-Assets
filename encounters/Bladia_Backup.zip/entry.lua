local package_id = "com.EXE5.Bladia"
local character_id = "com.EXE5.Bladia.Enemy"

function package_requires_scripts()
    Engine.define_character(character_id, _modpath.."virus")
end

function package_init(package) 
    package:declare_package_id(package_id)
    package:set_name("Bladia")
    package:set_description("And steadily it would decline, in to its solitary shell.")
    package:set_speed(1)
    package:set_attack(50)
    package:set_health(200)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob, data)
    mob:enable_freedom_mission(3, false)
    local rank = Rank.V1
    if data.rank then rank = data.rank end
    mob:create_spawner(character_id, rank):spawn_at(5, 2):mutate(function(character)
        if data.health then
            character:set_health(data.health)
        end
    end)
end